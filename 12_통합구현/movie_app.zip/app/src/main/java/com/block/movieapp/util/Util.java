package com.block.movieapp.util;

public class Util {

    public static final String BASE_URL = "http://contactserver5-env.eba-5yvw6x6m.ap-northeast-2.elasticbeanstalk.com";
}
