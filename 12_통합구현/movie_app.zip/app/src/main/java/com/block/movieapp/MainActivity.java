package com.block.movieapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.block.movieapp.adapter.RecyclerViewAdapter;
import com.block.movieapp.model.Movie;
import com.block.movieapp.util.Util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText edit_search;
    ImageButton btn_search;
    Button btn_year;
    Button btn_attendance;
    RecyclerView recyclerView;

    RecyclerViewAdapter adapter;
    ArrayList<Movie> movieArrayList = new ArrayList<>();

    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit_search = findViewById(R.id.edit_search);
        btn_search = findViewById(R.id.btn_search);
        btn_year = findViewById(R.id.btn_year);
        btn_attendance = findViewById(R.id.btn_attendance);
        recyclerView = findViewById(R.id.recycler_view);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        requestQueue = Volley.newRequestQueue(MainActivity.this);

        getNetworkData();

    }

    private void getNetworkData() {
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET,
                Util.BASE_URL + "/api/v1/movies?offset=0&limit=25",
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("AAA", response.toString());

                        try {
                            boolean success = response.getBoolean("success");
                            if(success == false){
                                // 유저한테 에러있다고 알리고 리턴.
                                return;
                            }
                            JSONArray items = response.getJSONArray("items");
                            for(int i = 0; i < items.length(); i++){
                                int id = items.getJSONObject(i).getInt("id");
                                String title = items.getJSONObject(i).getString("title");
                                String genre = items.getJSONObject(i).getString("genre");
                                int attendance = items.getJSONObject(i).getInt("attendance");
                                String year = items.getJSONObject(i).getString("year");
                                int reply_cnt = items.getJSONObject(i).getInt("reply_cnt");

                                Double avg_rating;
                                if(items.getJSONObject(i).isNull("avg_rating")){
                                    avg_rating = 0.0;
                                }else{
                                    avg_rating = items.getJSONObject(i).getDouble("avg_rating");
                                }

                                Movie movie = new Movie(id, title, genre, attendance,year,reply_cnt,avg_rating);
                                movieArrayList.add(movie);
                            }

                            adapter = new RecyclerViewAdapter(MainActivity.this, movieArrayList);
                            recyclerView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );

        requestQueue.add(request);
    }
}









