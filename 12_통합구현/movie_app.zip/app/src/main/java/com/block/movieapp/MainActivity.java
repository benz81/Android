package com.block.movieapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    EditText edit_search;
    ImageButton btn_search;
    Button btn_year;
    Button btn_attendance;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit_search = findViewById(R.id.edit_search);
        btn_search = findViewById(R.id.btn_search);
        btn_year = findViewById(R.id.btn_year);
        btn_attendance = findViewById(R.id.btn_attendance);
        recyclerView = findViewById(R.id.recycler_view);

    }
}