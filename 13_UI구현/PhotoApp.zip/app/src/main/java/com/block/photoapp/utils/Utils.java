package com.block.photoapp.utils;

public class Utils {

    public static final String BASE_URL = "http://contactserver5-env.eba-5yvw6x6m.ap-northeast-2.elasticbeanstalk.com";
    public static final String PREFERENCES_NAME = "photo_app";
}
